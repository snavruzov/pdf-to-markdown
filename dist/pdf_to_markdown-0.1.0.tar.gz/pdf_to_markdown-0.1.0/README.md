# MarkItDown PDF Converter Plugin

This project provides a **MarkItDown plugin** for converting PDF files to Markdown with a strong emphasis on extracting _all_ content, including text, tables, and images—even from challenging or scanned documents. The plugin is designed for **correctness over speed**, ensuring that as much information as possible is preserved in the Markdown output.

## Features

- **Text Extraction**: Uses [PyMuPDF](https://pymupdf.readthedocs.io/) and [pymupdf4llm](https://pymupdf.readthedocs.io/en/latest/pymupdf4llm/index.html) to extract text, tables, and images from PDFs when possible.
- **Fallback to LLM-based OCR**: If text extraction is incomplete (e.g., for scanned pages, complex tables, or images), the plugin automatically falls back to an LLM-based OCR service. This ensures that even non-searchable or image-based content is converted to Markdown.
- **Table and Image Handling**: Tables and images are extracted and, if necessary, described or transcribed using the LLM OCR backend.
- **Correctness First**: The plugin prioritizes extracting _everything_ from the PDF, even if this means slower processing due to LLM calls for OCR or table/image understanding.

## How It Works

1. **Text Extraction**: For each page, the plugin first attempts to extract text, tables, and images using PyMuPDF and pymupdf4llm.
2. **Heuristics for OCR**: If a page is detected as non-readable (e.g., scanned, mostly images, or simulated text), it is sent to the LLM-based OCR service for processing.
3. **LLM OCR Fallback**: The plugin uses a configurable LLM client (such as OpenAI's GPT-4o) to perform OCR and generate Markdown for images, tables, and non-readable content.
4. **Combining Results**: All extracted and OCR'd content is merged into a single Markdown output, with clear page and section boundaries.

## Dependencies

- Python 3.11+
- [PyMuPDF](https://pymupdf.readthedocs.io/) (`pymupdf`)
- [pymupdf4llm](https://github.com/markitdown-ai/pymupdf4llm`)
- [Pillow](https://python-pillow.org/)
- [tqdm](https://tqdm.github.io/) (for progress bars)
- [markitdown](https://github.com/markitdown-ai/markitdown)
- An LLM client (e.g., OpenAI Python SDK) for OCR fallback

All dependencies are listed in `pyproject.toml`.

## Installation

1. **Clone the repository**:
   ```bash
   git clone <this-repo-url>
   cd pdf-to-markdown
   ```
2. **Install dependencies** (using [Poetry](https://python-poetry.org/) or pip):
   ```bash
   poetry install
   # or
   pip install -r requirements.txt
   ```

## Usage

This plugin is designed to be used as a MarkItDown converter. You can use it programmatically:

```python
from markitdown import MarkItDown
from pdf_to_markdown.markitdown_mupdf_converter import register_converters

# Optionally, provide your LLM client and model for OCR fallback
llm_client = ...  # e.g., OpenAI client
llm_model = "gpt-4o"

mid = MarkItDown(
    custom_pdf_ocr_service=None,  # or your own OCR service that implements the OCRInterface 
    llm_client=llm_client,
    llm_model=llm_model,
)
register_converters(mid)

with open("example.pdf", "rb") as f:
    result = mid.convert(f, extension=".pdf")
    print(result.markdown)
```

## Configuration
- You can provide your own OCR service or use the built-in LLM-based OCR (requires an OpenAI-compatible client).
- The plugin will automatically decide when to use OCR based on page content heuristics.

## Notes
- **Performance**: Because the plugin prioritizes correctness and completeness, processing may be slower than pure text extractors, especially for scanned or image-heavy PDFs.
- **LLM Costs**: Using LLM-based OCR may incur API costs depending on your provider and the number of pages/images processed.

## License

MIT License 