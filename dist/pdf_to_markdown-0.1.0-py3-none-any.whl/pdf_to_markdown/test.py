from markitdown import MarkItDown

from pdf_to_markdown.markitdown_mupdf_converter import MuPdfMarkitdownConverter


def main():
    pdf_path = "test.pdf"
    mid = MarkItDown(use_plugins=True)
    
    md = mid.convert(pdf_path)
    print(md)
    


if __name__ == "__main__":
    main()